import { registerRootComponent } from 'expo';
import App from './App';

// Register the root component
registerRootComponent(App);